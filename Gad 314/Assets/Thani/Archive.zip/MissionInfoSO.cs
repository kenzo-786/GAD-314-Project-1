using UnityEngine;

[CreateAssetMenu(fileName = "MissionInfoSO", menuName = "ScriptableObjects/MissionInfoSO", order = 1)]

public class MissionInfoSO : ScriptableObject
{
    [field: SerializeField] public string id { get; private set; }

    public string displayName;

    public int levelRequirement;
    public MissionInfoSO[] missionPrerequisites;

    public GameObject[] questStepPrefabs;

    public string displayName;
}
