using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using UnityEngine;
using UnityEngine.Events;

public class MissionLogScrollingList : MonoBehaviour
{
    [SerializeField] private GameObject contentParent;

    [SerializeField] private RectTransform scrollRectTransform;
    [SerializeField] private RectTransform contentRectTransform;

    [SerializeField] private GameObject missionLogButtonPrefab;

    private Dictionary<string, MissionLogButton> idToButtonMap = new Dictionary<string, MissionLogButton>();

    private void Start()
    {
        for (int i = 0; i < 20; i++)
        {
            MissionInfoSO missionInfoTest = ScriptableObject.CreateInstance<MissionInfoSO>();
            missionInfoTest.id = "test";
            missionInfoTest.displayName = "Test " + i;
            missionInfoTest.quickStepPrefabs = new GameObject[0];
            Mission mission = new Mission(missionInfoTest);

            MissionLogButton missionLogButton = CreateButtonIfNotExists(quest, () => {
                Debug.Log("SELECTED: " + missionInfoTest.displayName);
            });

            if (i == 0)
            {
                missionLogButton.button.Select();
            }
        }
    }

    public MissionLogButton CreateButtonIfNotExists(Mission mission, UnityAction selectAction)
    {
        MissionLogButton missionLogButton = null;

        if (!idToButtonMap.ContainsKey(mission.info.id))
        {
            missionLogButton = InstantiateMissionLogButton(mission, selectAction);
        }
        else
        {
            missionLogButton = idToButtonMap[mission.info.id];
        }
        return missionLogButton;
    }

    private MissionLogButton InstantiateMissionLogButton(Mission mission, UnityAction selectAction)
    {
        MissionLogButton missionLogButton = Instantiate(missionLogButtonPrefab, contentParent.transform).GetComponent<MissionLogButton>();
        missionLogButton.gameObject.name = mission.info.id + "_button";
        RectTransform buttonRectTransform = missionLogButton.GetComponent<RectTransform>();
        missionLogButton.Initialize(mission.info.displayName, () => {
            selectAction();
            UpdateScrolling(buttonRectTransform);
        });
        idToButtonMap[mission.info.id] = missionLogButton;
        return missionLogButton;
    }

    private void UpdateScrolling(RectTransform buttonRectTransform)
    {
        float buttonYMin = Mathf.Abs(buttonRectTransform.anchoredPosition.y);
        float buttonYMax = buttonYMin + buttonRectTransform.rect.height;

        float contentYMin = contentRectTransform.anchoredPosition.y;
        float contentYMax = contentYMin + scrollRectTransform.rect.height;

        if (buttonYMax > contentYMax)
        {
            contentRectTransform.anchoredPosition = new Vector2(contentRectTransform.anchoredPosition.x, buttonYMax - scrollRectTransform.rect.height);
        }

        else if (buttonYMin < contentYMin)
        {
            contentRectTransform.anchoredPosition = new Vector2(contentRectTransform.anchoredPosition.x, buttonYMin);
        }
    }
}
